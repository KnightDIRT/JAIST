Download Metric Depth Anything checkpoint from:
https://huggingface.co/spaces/LiheYoung/Depth-Anything/tree/main/checkpoints_metric_depth

Git Clone:
github.com/LiheYoung/Depth-Anything
github.com/weizequan/LGNet